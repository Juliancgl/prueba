﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcLoginAppDemo.Controllers;
using MvcLoginAppDemo;

namespace testProyect
{
    [TestClass]
    public class HomeTestController
    {
        private HomeController inst = new HomeController();
        private UserProfile mock;
        [TestMethod]
        public void login()
        {
            mock = new UserProfile() {UserName= "prueba", Password="12345678" , UserId = 1, IsActive = true };
            Assert.IsNotNull(inst.Login(mock));
        }
        [TestMethod]
        public void batlogin()
        {
            try
            {
                inst.Login(mock);
            }
            catch (Exception ex) {
                Assert.Fail(ex.Message);
            }
            
        }
        [TestMethod]
        public void batadd()
        {
            mock = new UserProfile() { UserName = "andres", Password = "123456789" };
            Assert.IsNotNull(inst.adduser(mock));
        }
        [TestMethod]
        public void add()
        {
            mock = new UserProfile() {  UserName = "andres", Password = "123456789" , UserId=12, IsActive=true};
            Assert.IsNotNull(inst.adduser(mock));
        }
    }
}
